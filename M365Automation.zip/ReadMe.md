# Microsoft 365 Automation Demo using Microsoft365Dsc

For more info, checkout [this whitepaper](https://microsoft365dsc.com/Pages/Resources/Whitepapers/Managing%20Microsoft%20365%20with%20Microsoft365Dsc%20and%20Azure%20DevOps.pdf).